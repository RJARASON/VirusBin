try:
    import os
    import time
    import sys
    import struct
    import asyncio
    try:
        async def FileStart():
            os.system("cls")
            print("executing...")
            time.sleep(2)
            print("'Open log'")
            logfile=open('FileV\log.log','wb')
            while True:
                logfile.write(b'002200')
                # logfile.write(b'Remote')
                # logfile.write(struct.pack('>i',0o2))
        asyncio.run(FileStart())
    except KeyboardInterrupt:
        os.system("cls")
        print("Internal Error occured.")
        sys.exit()
    except Exception:
        os.system("cls")
        print("Internal Error occured.")
        sys.exit()
except KeyboardInterrupt:
    os.system("cls")
    print("Internal Error occured.")
    sys.exit()
except Exception:
    os.system("cls")
    print("Internal Error occured.")
    sys.exit()